<?php get_header();?>
  <section id="offer"> 
    <!-- The offer section displays a banner text for promotions -->
    <div id="carouselExampleIndicators1" class="carousel slide" data-ride="carousel" style="background-color: grey">

      <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators1" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators1" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators1" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <div class="carousel-item active"> <img class="d-block mx-auto" src="<?php echo get_template_directory_uri().'/assets/' ?>images/Carousel_Placeholder.png" alt="First slide">
          <div class="carousel-caption">
            <h5>First slide Heading</h5>
            <p>First slide Caption</p>
          </div>
        </div>
        <div class="carousel-item"> <img class="d-block mx-auto" src="<?php echo get_template_directory_uri().'/assets/' ?>images/Carousel_Placeholder.png"alt="Second slide">
          <div class="carousel-caption">
            <h5>Second slide Heading</h5>
            <p>Second slide Caption</p>
          </div>
        </div>
        <div class="carousel-item"> <img class="d-block mx-auto" src="<?php echo get_template_directory_uri().'/assets/' ?>images/Carousel_Placeholder.png" alt="Third slide">
          <div class="carousel-caption">
            <h5>Third slide Heading</h5>
            <p>Third slide Caption</p>
          </div>
        </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators1" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carouselExampleIndicators1" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> </div>
<h2>&nbsp;</h2>
    <p>&nbsp;</p>
  </section>
  <hr>
	<div class="container">
        <div class="row">
          <div class="col-lg-4 col-md-6 col-12">
            <ul class="list-unstyled">
              <li class="media">
               
                <div class="media-body">
                  <h5 class="mt-0 mb-1">Heading 1</h5>
                  <p class="mb-0">Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.</p>
                </div>
              </li>
            </ul>
          </div>
          <div class="col-lg-4 col-md-6 col-12">
            <ul class="list-unstyled">
              <li class="media">
                
                <div class="media-body ">
                  <h5 class="mt-0 mb-1">Heading 2</h5>
                  <p class="mb-0">Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.</p>
                </div>
              </li>
            </ul>
          </div>
          <div class="col-lg-4 d-md-none d-lg-block">
            <ul class="list-unstyled">
              <li class="media">
                
                <div class="media-body">
                  <h5 class="mt-0 mb-1">Heading 3</h5>
                  <p class="mb-0">Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis.</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <hr>
  <div id="content">
    <section class="sidebar"> 
      <!-- This adds a sidebar with 1 searchbox,2 menusets, each with 4 links -->
      <input type="text"  id="search" value="search">
      <div id="menubar">
        <nav class="menu">
          <h2><!-- Title for menuset 1 -->MENU ITEM 1 </h2>
          <hr>
          <ul>
            <!-- List of links under menuset 1 -->
            <li><a href="#" title="Link">Link 1</a></li>
            <li><a href="#" title="Link">Link 2</a></li>
            <li><a href="#" title="Link">Link 3</a></li>
            <li class="notimp"><!-- notimp class is applied to remove this link from the tablet and phone views --><a href="#"  title="Link">Link 4</a></li>
          </ul>
        </nav>
        <nav class="menu">
          <h2>MENU ITEM 2 </h2>
          <!-- Title for menuset 2 -->
          <hr>
          <ul>
            <!--List of links under menuset 2 -->
            <li><a href="#" title="Link">Link 1</a></li>
            <li><a href="#" title="Link">Link 2</a></li>
            <li><a href="#" title="Link">Link 3</a></li>
            <li class="notimp"><!-- notimp class is applied to remove this link from the tablet and phone views --><a href="#" title="Link">Link 4</a></li>
          </ul>
        </nav>
      </div>
      <h4>New Properties</h1>
		<table width="200" border="1" style="border: 0px">
  <tbody>
    <tr>
      <td><img class="d-block mx-auto" src="<?php echo get_template_directory_uri().'/assets/' ?>images/Carousel_Placeholder.png" alt="Second slide" height="50px" width="50px"></td>
      <td><img class="d-block mx-auto" src="<?php echo get_template_directory_uri().'/assets/' ?>images/Carousel_Placeholder.png" alt="Second slide" height="50px" width="50px"></td>
      <td><img class="d-block mx-auto" src="<?php echo get_template_directory_uri().'/assets/' ?>images/Carousel_Placeholder.png" alt="Second slide" height="50px" width="50px"></td>
    </tr>
    <tr>
      <td><img class="d-block mx-auto" src="<?php echo get_template_directory_uri().'/assets/' ?>images/Carousel_Placeholder.png" alt="Second slide" height="50px" width="50px"></td>
      <td><img class="d-block mx-auto" src="<?php echo get_template_directory_uri().'/assets/' ?>images/Carousel_Placeholder.png" alt="Second slide" height="50px" width="50px"></td>
      <td><img class="d-block mx-auto" src="<?php echo get_template_directory_uri().'/assets/' ?>images/Carousel_Placeholder.png" alt="Second slide" height="50px" width="50px"></td>
    </tr>
    <tr>
      <td><img class="d-block mx-auto" src="<?php echo get_template_directory_uri().'/assets/' ?>images/Carousel_Placeholder.png" alt="Second slide" height="50px" width="50px"></td>
      <td><img class="d-block mx-auto" src="<?php echo get_template_directory_uri().'/assets/' ?>images/Carousel_Placeholder.png" alt="Second slide" height="50px" width="50px"></td>
      <td><img class="d-block mx-auto" src="<?php echo get_template_directory_uri().'/assets/' ?>images/Carousel_Placeholder.png" alt="Second slide" height="50px" width="50px"></td>
    </tr>
  </tbody>
</table>

		
    </section>
    <section class="mainContent">
      <div class="productRow"><!-- Each product row contains info of 3 elements -->
      <?php if (have_posts()): ?>
        <?php while (have_posts()): ?>
          <?php the_post(); ?>
        <article class="productInfo"><!-- Each individual product description -->
          <div><img alt="sample" src="<?php echo get_the_post_thumbnail_url();  ?>"></div>
          <p class="price"><?php the_title(); ?></p>
          <p class="productContent"><?php the_content(); ?></p>
          <input type="button" name="button" value="Buy" class="buyButton">
        </article>
      <?php endwhile; ?>
      <?php endif; ?>
        
      </div>

      
    </section>
  </div>
 <?php get_footer();?> 
