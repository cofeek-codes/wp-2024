<?php 
add_action('wp_enqueue_scripts', 'include_style');
add_action('wp_enqueue_scripts', 'include_scripts');
add_action('after_setup_theme', 'theme');
function include_style() {    
wp_enqueue_style('s1', get_template_directory_uri().'/assets/css/styles/bootstrap-4.4.1.css');
wp_enqueue_style('s2', get_template_directory_uri().'/assets/css/styles/eCommerceStyle.css');
wp_enqueue_style('s3', get_stylesheet_uri());


}
function include_scripts(){
wp_enqueue_script('jq',get_template_directory_uri()."/assets/js/jquery-3.4.1.min.js");
wp_enqueue_script('sc2',get_template_directory_uri()."/assets/js/bootstrap-4.4.1.js",["jq"]);
wp_enqueue_script('sc1',get_template_directory_uri()."/assets/js/popper.min.js",["jq"]);


}
function theme()
{
add_theme_support('custom-logo');
add_theme_support('post-thumbnails',['post']);


}    
