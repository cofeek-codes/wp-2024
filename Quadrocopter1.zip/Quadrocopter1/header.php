<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>eCommerce template By Adobe Dreamweaver</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="eCommerceAssets/styles/eCommerceStyle.css" rel="stylesheet" type="text/css">
<link href="eCommerceAssets/styles/bootstrap-4.4.1.css" rel="stylesheet" type="text/css">
<!--The following script tag downloads a font from the Adobe Edge Web Fonts server for use within the web page. We recommend that you do not modify it.-->
<script>var __adobewebfontsappname__="dreamweaver"</script><script src="http://use.edgefonts.net/montserrat:n4:default;source-sans-pro:n2:default.js" type="text/javascript"></script>
<?php wp_head(); ?>
</head>


<body>
<div id="mainWrapper">
  <header>
  <?php the_custom_logo();?> 
    <div id="headerLinks"><a href="#" title="Login/Register">Вход</a><a href="#" title="Login/Register">Регистрация</a></div>
  </header>